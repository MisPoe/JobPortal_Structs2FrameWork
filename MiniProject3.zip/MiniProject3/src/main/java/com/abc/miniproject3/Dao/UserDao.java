package com.abc.miniproject3.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.abc.miniproject3.model.User;
import com.abc.miniproject3.config.DBConfig;

public class UserDao {
	Connection con;
	PreparedStatement pst;
	User user;
	List<User> users;

	public UserDao() {
		this.user = null;
		this.users = null;
		this.con = DBConfig.getConnection();
	}
	
		//////////////////Register //////////////////////////////////
		
		public int registerUser(String fname, String uname, String email,String phone, String password) {
		// TODO Auto-generated method stub
		int flag = 0;
		try {
		String sql = "insert into user(full_name,user_name,email,role_id,phone,password) values(?,?,?,?,?,?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, fname);
		ps.setString(2, uname);
		ps.setString(3, email);
		ps.setInt(4, 2);
		ps.setString(5, phone);
		ps.setString(6, password);
		
		
		flag = ps.executeUpdate();
		if (flag > 0) {
			System.out.println("User Register Successful");
		}
		} catch (SQLException e) {
		e.printStackTrace();
		}
		return flag;
		}

			////////////////// End Register/////////////////////////////////
	
	 	///////////// For Login Process //////////////////////////////

	public User getUserByEmail(String email, String password) throws SQLException {

		System.out.println("login user DAO");
		System.out.println("Login Email is " + email);
		System.out.println("Login Password is " + password);

		User user = null;
		try {
			String sql = "select * from user where email=? and password=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();

			while (rs.next()) {
				user = new User();
				user.setUser_id(rs.getInt("user_id"));
				user.setFull_name(rs.getString("full_name"));
				user.setUser_name(rs.getString("user_name"));
				user.setEmail(rs.getString("email"));
				user.setRole_id(rs.getInt("role_id"));
				user.setPhone(rs.getString("phone"));
				user.setPassword(rs.getString("password"));
				
			}

			System.out.println("login user row is " + user);
			return user;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (con != null) {
				con.close();
				System.out.println("Connectoin close");
			}
		}
	}

	///////////// End Login Process //////////////////////////////
	
/////////////////////////////////////////Forget Password /////////////////////////////////////

			public User checktUserByEmail(String email) throws SQLException {
			
			System.out.println("Check user email  DAO");
			System.out.println("check Email is " + email);
			
			User user = null;
			try {
			String sql = "select * from user where email=?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, email);
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				user = new User();
				user.setUser_id(rs.getInt("user_id"));
				user.setFull_name(rs.getString("full_name"));
				user.setUser_name(rs.getString("user_name"));
				user.setEmail(rs.getString("email"));
				user.setRole_id(rs.getInt("role_id"));
				user.setPhone(rs.getString("phone"));
				user.setPassword(rs.getString("password"));
				
			}
			
			System.out.println("Check user is " + user);
			return user;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (con != null) {
				con.close();
				System.out.println("Connectoin close");
			}
		}
	}
			
			
			public int updatePassword(String password, String email)
					throws SQLException, Exception {
				
				int i = 0;
				try {
					System.out.println("Update Password "+password);
					System.out.println("Update Email "+email);
					
					String sql = "UPDATE user SET password=? WHERE email=?";
					PreparedStatement ps = con.prepareStatement(sql);
					ps.setString(1, password);
					ps.setString(2, email);
					i = ps.executeUpdate();
					return i;
				} catch (Exception e) {
					e.printStackTrace();
					return 0;
				} finally {
					if (con != null) {
						con.close();
					}
				}
			}

//////////////////////////////////////End Forget Password/////////////////////////////////////
			
/////////////////////// Profile //////////////////////////////

			public User getUserById(int userid) throws SQLException {
			
			System.out.println("Get User by Dao Method");
			User user = null;
			try {
				String sql = "select * from user where user_id=?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setInt(1, userid);
				ResultSet rs = ps.executeQuery();
			
				while (rs.next()) {
					user = new User();
					user.setUser_id(rs.getInt("user_id"));
					user.setFull_name(rs.getString("full_name"));
					user.setUser_name(rs.getString("user_name"));
					user.setEmail(rs.getString("email"));
					user.setRole_id(rs.getInt("role_id"));
					user.setPhone(rs.getString("phone"));
					user.setPassword(rs.getString("password"));
					user.setHobbies(rs.getString("hobbies"));
					user.setAbout(rs.getString("about"));
					user.setAddress(rs.getString("address"));
					user.setJob_experience(rs.getString("job_experience"));
				}
			
				System.out.println("Profile User is " + user);
				return user;
			
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			} finally {
				if (con != null) {
					con.close();
					System.out.println("Connection close");
				}
			}
			}
			
			public int updateUser(User user) {
			System.out.println(" Update User DAO");
			int flag = 0;
			try {
				String sql = "update user set full_name=? , user_name=? , email=?, password=?, hobbies=?, about=?, address=?, job_experience=? where user_id=?";
				PreparedStatement ps = con.prepareStatement(sql);
				ps.setString(1, user.getFull_name());
				ps.setString(2, user.getUser_name());
				ps.setString(3, user.getEmail());
				ps.setString(4, user.getPassword());
				ps.setString(5, user.getHobbies());
				ps.setString(6, user.getAbout());
				ps.setString(7, user.getAddress());
				ps.setString(8, user.getJob_experience());
				ps.setInt(9, user.getUser_id());
				flag = ps.executeUpdate();
			
				if (flag > 0) {
					System.out.println("User Update is Successful");
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return flag;
			
			}

//////////////////////////////End Profile ////////////////////////////////////////////////

}
