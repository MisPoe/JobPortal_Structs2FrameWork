package com.abc.miniproject3.action;

import javax.servlet.http.HttpServlet;

import com.opensymphony.xwork2.ActionSupport;

public class ConfirmEmailAction extends ActionSupport{
	
	@Override
	public String execute() throws Exception {
		
		return "ConfirmEmail";
}
	public String execute1() throws Exception {
		return "afterconfrim_login";
	}
}